use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader};
use crate::graph::Graph;
use rustworkx_core::petgraph::graph::{DiGraph, NodeIndex};
use rustworkx_core::centrality::betweenness_centrality;

//Function in order to read the data. Outuput is the number of edges, list of connections.
pub fn read_data(path: &str) -> (usize, Vec<(usize, usize)>) {
    let file = File::open(path).expect("Could not open file!");
    let reader = BufReader::new(file);
    let lines = reader.lines();

    //Initialize a HashMap to be used in later stage to label the nodes.
    let mut label_mapping: HashMap<u32, usize> = HashMap::new(); 
     //Initialize a label tracker
    let mut next_label: usize = 0;
    let mut edges = Vec::new();

    let mut edge_set = std::collections::HashSet::new(); // HashSet to track unique edges

    //Iterating over each line from the text file and collecting each number seperatly as x and y.
    for line in lines {
        let line_str = line.expect("Could not read line.");
        let v: Vec<&str> = line_str.trim().split(" ").collect();

        let x = v[0].parse::<u32>().unwrap();
        let y = v[1].parse::<u32>().unwrap();

        //Mapping original values to labels (0..n-1 using a HashMap)
        let x_mapped = *label_mapping.entry(x).or_insert_with(|| {
            let label = next_label;
            next_label += 1;
            label
        });
        let y_mapped = *label_mapping.entry(y).or_insert_with(|| {
            let label = next_label;
            next_label += 1;
            label
        });

       // Check if the edge is already in the edge_set
       if !edge_set.contains(&(x_mapped, y_mapped)) {
        edges.push((x_mapped, y_mapped));
        edge_set.insert((x_mapped, y_mapped)); // Add the edge to the edge_set
        }
    }
    (label_mapping.len(), edges)
}

//Function in order to create the graph. Inputs are number of edges and a list of connections. Output is a Graph struct 
pub fn create_graph(nodes: usize, edges: Vec<(usize, usize)>) -> Graph {
    let mut graph = Graph::new(nodes);
    for (x,y) in edges {
        graph.add_edge(x, y);
    }
    graph
}

// Function to convert an adjacency list representation to an edge list representation.
pub fn adjacency_list_to_edge_list(adjacency_list: &Vec<Vec<usize>>) -> Vec<(usize, usize)> {
    let mut edge_list = Vec::new();

    for (node, neighbors) in adjacency_list.iter().enumerate() {
        for &neighbor in neighbors {
            edge_list.push((node, neighbor));
        }
    }

    edge_list
}
// Function to create a subgraph from the top k nodes of the given graph and the specified depth. Returns a Graph struct.
pub fn subgraph_from_topk_nodes(graph: &Graph, topk_nodes: &Vec<usize>, depth: usize) -> Graph {
    let mut subgraph_adjacency_list: Vec<Vec<usize>> = Vec::new();
    let mut subgraph_incoming_edges_count: Vec<usize> = Vec::new();
    let mut subgraph_mapping: HashMap<usize, usize> = HashMap::new();

    // Iterate through the top k nodes
    for &node in topk_nodes {
        let mut queue = std::collections::VecDeque::new();
        let mut visited = std::collections::HashSet::new();
        queue.push_back((node, 0));

        // Perform a breadth-first search (BFS) from each node up to the specified depth
        while let Some((current_node, current_depth)) = queue.pop_front() {
            if visited.contains(&current_node) {
                continue;
            }
            visited.insert(current_node);

            let subgraph_index = subgraph_mapping.len();
            subgraph_mapping.entry(current_node).or_insert(subgraph_index);
            subgraph_adjacency_list.push(graph.adjacency_list[current_node].clone());
            subgraph_incoming_edges_count.push(graph.incoming_edges_count[current_node]);

            if current_depth < depth {
                for &neighbor in &graph.adjacency_list[current_node] {
                    queue.push_back((neighbor, current_depth + 1));
                }
            }
        }
    }

    // Update the adjacency list with subgraph indices
    for node_list in &mut subgraph_adjacency_list {
        for neighbor in node_list.iter_mut() {
            if let Some(mapped_neighbor) = subgraph_mapping.get(neighbor) {
                *neighbor = *mapped_neighbor;
            } else {
                continue;
            }
        }
    }

    Graph {
        adjacency_list: subgraph_adjacency_list,
        incoming_edges_count: subgraph_incoming_edges_count,
    }
}

pub fn create_petgraph(edges: &Vec<(usize, usize)>) -> DiGraph<i32, ()> {
    // Convert the edges from (usize, usize) to (NodeIndex, NodeIndex)
    let nodeindex_edges: Vec<(NodeIndex<u32>, NodeIndex<u32>)> = edges
        .iter()
        .map(|(x, y)| (NodeIndex::new(*x), NodeIndex::new(*y)))
        .collect();

    // Create the petgraph DiGraph from the converted edges
    let g = DiGraph::<i32, ()>::from_edges(nodeindex_edges);
    g
}

pub fn top_n_centrality(graph: &DiGraph::<i32, ()>, n: usize) -> Vec<(usize, f64)> {
    let centrality = betweenness_centrality(&graph, false, true, 200);

    let mut top_10_indices_and_values: Vec<(usize, f64)> = centrality
        .iter()
        .enumerate()
        .filter_map(|(index, value_option)| match value_option {
            Some(value) => Some((index, *value)),
            None => None,
        })
        .collect();

    // Sort by centrality values in descending order
    top_10_indices_and_values.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap());

    // Select top 10 elements
    let top_10: Vec<(usize, f64)> = top_10_indices_and_values.into_iter().take(n).collect();

    top_10
}