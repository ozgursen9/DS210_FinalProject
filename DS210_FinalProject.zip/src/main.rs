mod graph;
mod functions;

use crate::functions::{read_data, create_graph, adjacency_list_to_edge_list, subgraph_from_topk_nodes, create_petgraph, top_n_centrality};

fn main() {
    // Read the raw data.
    let (nodes, edges) = read_data("twitter_combined.txt");
    let main_graph = create_graph(nodes, edges.clone());
    
    let k = 10;
    // Get the top k nodes.
    let topk = main_graph.get_topk_nodes(k);
    let topk_nodes: Vec<usize> = topk.clone().into_iter().map(|(node, _)| node).collect();

    let n = 1;
    // Get the subgraph with n depth neighbours of the top k nodes.
    let subgraph = subgraph_from_topk_nodes(&main_graph, &topk_nodes, n);
    // Convert to an edge list so it can be loaded as a petgraph.
    let subgraph_edge_list = adjacency_list_to_edge_list(&subgraph.adjacency_list);
    let petgraph = create_petgraph(&subgraph_edge_list);

    // Calculate centrality for the top k nodes
    let centrality = top_n_centrality(&petgraph, k);
    
    // Print the results
    for (x,y) in topk.iter(){
         println!("Node: {:?}. Followers: {:?}.", x, y);
    }
    println!("--------------------------");
     for (x,y) in centrality.iter(){
         println!("Node: {:?}. Centrality: {:?}.", x, y);
     }
}


//Test given that the from the dataset description we know there should be 81306 nodes. 
#[test]
fn test_node_count() {
    let (nodes, edges) = read_data("twitter_combined.txt");
    let graph = create_graph(nodes, edges);
    let graph_node_count: usize = graph.adjacency_list.len();
    let node_count = 81306;

    assert_eq!(graph_node_count, node_count, "Graph is unsuccesfull.");
}

//Test given that the from the dataset description we know there should be 1768149 edges. 
#[test]
fn test_edge_count() {
    let (nodes, edges) = read_data("twitter_combined.txt");
    let graph = create_graph(nodes, edges);
    let edge_count = 1768149;
    let edge_counter: usize = graph.incoming_edges_count.iter().map(|&x| x).sum();

    assert_eq!(edge_count, edge_counter, "Graph is unsuccessful.");
}

