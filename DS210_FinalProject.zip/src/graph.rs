// Defining the main graph struct in order to represent our graph. 
#[derive(Debug)]
pub struct Graph {
    pub adjacency_list: Vec<Vec<usize>> ,
    pub incoming_edges_count: Vec<usize>, // I am adding this field for future purposes of finding the users with the most followers.
}

//Implement methods to create the graph and add elements to it such as nodes and edges.
impl Graph {
    // Defines a brand new empty graph.
    pub fn new(size: usize) -> Self {
        Graph {
            adjacency_list: vec![Vec::new(); size],
            incoming_edges_count: vec![0; size],
        }
    }
    // Adds edge to the adjaceny list, and increases the number of incoming edges by one. 
    pub fn add_edge(&mut self, from: usize, to: usize) {
        self.adjacency_list[from].push(to);
        self.incoming_edges_count[to] += 1;
    }
    pub fn get_topk_nodes(&self, k: usize) -> Vec<(usize, usize)> {
        let mut nodes: Vec<(usize, usize)> = self //Creates a vector of tuples containing each node and its incoming edges count,
            .incoming_edges_count
            .iter()
            .enumerate()
            .map(|(node, count)| (node, *count))
            .collect();

        nodes.sort_by_key(|(_, count)| std::cmp::Reverse(*count)); // Sort the vector in descending order based on the incoming edges count,
        nodes.into_iter().take(k).collect()
    }
}    
